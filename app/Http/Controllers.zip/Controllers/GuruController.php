<?php

namespace App\Http\Controllers;

use App\Models\Keguruan;
use Illuminate\Http\Request;

class GuruController extends Controller
{
    public function index($slug)
    {
        //
    }
}
