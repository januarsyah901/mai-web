<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
{{-- <link rel="shortcut icon" href="/assets/assets/img/photos/mai/logoMAI.png"> --}}
<title>MAI Amanatul Ummah || {{ $title }}</title>
<link rel="stylesheet" href="/assets/assets/css/plugins.css">
<link rel="stylesheet" href="/assets/assets/css/style.css">
<link rel="stylesheet" href="/assets/assets/css/colors/green.css">
<link rel="stylesheet" href="/assets/css/fe_style.css">