<section class="wrapper bg-gray">
    <div class="container pt-10 pt-md-14 text-center">
        <div class="row">
            <div class="col-xl-6 mx-auto">
                <h1 class="display-1 mb-1">MAU Amanatul Ummah program Istimewa Layanan SKS 2 dan 3 Tahun</h1>
                <p class="lead fs-lg mb-0">Sekolahnya generasi istimewa!</p>
            </div>
            <!-- /column -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
    <figure class="position-absoute" style="bottom: 0; left: 0; z-index: 2; margin-top:-30px"><img
            src="/assets/assets/img/photos/mai/masjid2-tes2.png" alt="" style="" /></figure>
</section>
<!-- /section -->